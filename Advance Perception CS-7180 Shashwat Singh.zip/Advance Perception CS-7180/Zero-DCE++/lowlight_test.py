"""
Shashwat Singh
CS-7180 Advance Perception
18/9/2025
Taken from Official Zero-DCE++ repo
"""

import torch
import torch.nn as nn
import torchvision
import torch.optim
import os
import sys
import argparse
import time
import dataloader
import model
import numpy as np
from torchvision import transforms
from PIL import Image
import glob
import time

# Choose device once (CPU if no CUDA build/GPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def lowlight(image_path):
    # Do NOT force CUDA; remove CUDA_VISIBLE_DEVICES entirely
    scale_factor = 12

    # Always open as RGB to avoid 1/4 channel surprises
    pil_img = Image.open(image_path).convert("RGB")

    # HxWxC in [0,1]
    data_lowlight = np.asarray(pil_img, dtype=np.float32) / 255.0

    # Torch tensor, make sure memory layout is sane
    data_lowlight = torch.from_numpy(data_lowlight).contiguous()

    # Make dimensions divisible by scale_factor
    h = (data_lowlight.shape[0] // scale_factor) * scale_factor
    w = (data_lowlight.shape[1] // scale_factor) * scale_factor
    data_lowlight = data_lowlight[0:h, 0:w, :]

    # To CHW and batch it, send to device
    data_lowlight = data_lowlight.permute(2, 0, 1).unsqueeze(0).to(device)

    # Build model and load weights to the SAME device
    DCE_net = model.enhance_net_nopool(scale_factor).to(device)
    ckpt = torch.load('snapshots_Zero_DCE++/Epoch99.pth', map_location=device)
    DCE_net.load_state_dict(ckpt)
    DCE_net.eval()

    start = time.time()
    with torch.no_grad():
        enhanced_image, params_maps = DCE_net(data_lowlight)
    end_time = (time.time() - start)

    print(end_time)

    # Make output path
    # Example: data/test_data/xxx/yyy.jpg -> data/result_Zero_DCE++/xxx/yyy.jpg
    result_path = image_path.replace('test_data', 'result_Zero_DCE++')

    out_dir = os.path.dirname(result_path)
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    # torchvision.utils.save_image expects [0,1] tensor on any device
    # (save_image will move to CPU internally if needed)
    torchvision.utils.save_image(enhanced_image, result_path)

    return end_time

if __name__ == '__main__':
    torch.set_grad_enabled(False)  # extra safety; we only do inference

    filePath = 'data/test_data/'
    file_list = os.listdir(filePath)
    sum_time = 0.0

    for file_name in file_list:
        test_list = glob.glob(os.path.join(filePath, file_name, "*"))
        for image in test_list:
            print(image)
            sum_time += lowlight(image)

    print(sum_time)
