"""
Shashwat Singh
CS-7180 Advance Perception
18/9/2025

LIME (Low-Light Image Enhancement via Illumination Map Estimation) 

Features:
- Initial illumination (per-pixel MaxRGB)
- Structure-aware refinement via a one-shot sparse linear solve
- Gamma on illumination
- Reflectance recovery (division)
- Optional selective denoising (NL-Means via scikit-image)
- Simple CLI for single image or folder

Dependencies:
    numpy, scipy, scikit-image, opencv-python (for I/O & color)

Usage examples:
    python lime_lite.py --input ./dark.jpg --alpha 0.15 --gamma 0.8 --denoise none
    python lime_lite.py --input ./lowlight_folder --alpha 0.2 --gamma 0.8 --denoise nlmeans
"""
from __future__ import annotations
import argparse
import os
from typing import Tuple
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve, cg
from skimage.restoration import denoise_nl_means, estimate_sigma

try:
    import cv2
    _HAS_CV2 = True
except Exception:
    _HAS_CV2 = False
    from imageio.v2 import imread, imwrite

EPS = 1e-6

def read_image(path: str) -> np.ndarray:
    if _HAS_CV2:
        bgr = cv2.imread(path, cv2.IMREAD_COLOR)
        if bgr is None:
            raise FileNotFoundError(f"Could not read image: {path}")
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        rgb = rgb.astype(np.float32) / 255.0
    else:
        rgb = imread(path)
        if rgb.ndim == 2:
            rgb = np.stack([rgb, rgb, rgb], axis=-1)
        rgb = rgb.astype(np.float32)
        if rgb.max() > 1.0:
            rgb /= 255.0
    if rgb.ndim == 2:
        rgb = np.stack([rgb, rgb, rgb], axis=-1)
    if rgb.shape[2] == 4:
        rgb = rgb[:, :, :3]
    return np.clip(rgb, 0.0, 1.0)

def save_image(path: str, rgb: np.ndarray) -> None:
    rgb = np.clip(rgb, 0.0, 1.0)
    arr = (rgb * 255.0 + 0.5).astype(np.uint8)
    if _HAS_CV2:
        bgr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
        cv2.imwrite(path, bgr)
    else:
        from imageio.v2 import imwrite
        imwrite(path, arr)

def initial_illumination(rgb: np.ndarray) -> np.ndarray:
    """
    Per-pixel MaxRGB initial illumination map.
    """
    return np.max(rgb, axis=2)

def _diff_ops(h: int, w: int) -> Tuple[sparse.csr_matrix, sparse.csr_matrix]:
    """
    Build forward-difference operators Dh (horizontal) and Dv (vertical)
    for an image of size HxW. Vectorization: row-major flattening.
    """
    n = h * w

    # Horizontal differences (along width): (i,j+1) - (i,j)
    rows = []
    cols = []
    data = []
    for i in range(h):
        for j in range(w - 1):
            idx = i * w + j
            rows.extend([idx, idx])
            cols.extend([idx, idx + 1])
            data.extend([-1.0, 1.0])
    Dh = sparse.csr_matrix((data, (rows, cols)), shape=(n, n))

    # Vertical differences (along height): (i+1,j) - (i,j)
    rows = []
    cols = []
    data = []
    for i in range(h - 1):
        for j in range(w):
            idx = i * w + j
            rows.extend([idx, idx])
            cols.extend([idx, idx + w])
            data.extend([-1.0, 1.0])
    Dv = sparse.csr_matrix((data, (rows, cols)), shape=(n, n))

    return Dh, Dv

def refine_illumination(T_hat: np.ndarray, alpha: float = 0.15, eps: float = EPS, use_cg: bool = False) -> np.ndarray:
    """
    Solve: (I + alpha * (Dh^T Wh Dh + Dv^T Wv Dv)) t = t_hat
    where Wh/Wv are diagonal weights based on |Dh t_hat| and |Dv t_hat|.

    Returns refined illumination T (H x W).
    """
    h, w = T_hat.shape
    n = h * w
    Dh, Dv = _diff_ops(h, w)

    t_hat = T_hat.reshape(-1)

    # Compute gradient magnitudes on t_hat
    g_h = Dh @ t_hat
    g_v = Dv @ t_hat

    # Weights: Strategy II (1 / (|grad| + eps))
    w_h = 1.0 / (np.abs(g_h) + eps)
    w_v = 1.0 / (np.abs(g_v) + eps)

    Wh = sparse.diags(w_h, 0, shape=(n, n))
    Wv = sparse.diags(w_v, 0, shape=(n, n))

    A = sparse.eye(n, format="csr") + alpha * (Dh.T @ Wh @ Dh + Dv.T @ Wv @ Dv)

    # Solve
    if use_cg:
        t, info = cg(A, t_hat, maxiter=200)
        if info != 0:
            # Fall back to direct solve
            t = spsolve(A, t_hat)
    else:
        t = spsolve(A, t_hat)

    T = np.clip(t.reshape(h, w), 0.0, 1.0)
    return T

def apply_gamma(T: np.ndarray, gamma: float = 0.8) -> np.ndarray:
    return np.power(np.clip(T, EPS, 1.0), gamma)

def recover_reflectance(rgb: np.ndarray, T_gamma: np.ndarray, eps: float = EPS) -> np.ndarray:
    """Enhance by dividing each channel by illumination."""
    out = rgb / (T_gamma[..., None] + eps)
    return np.clip(out, 0.0, 1.0)

def rgb_to_yuv(rgb: np.ndarray) -> np.ndarray:
    if _HAS_CV2:
        return cv2.cvtColor(rgb.astype(np.float32), cv2.COLOR_RGB2YUV)
    # Manual matrix (BT.601 approx)
    M = np.array([[ 0.299,  0.587,  0.114],
                  [-0.14713, -0.28886, 0.436],
                  [ 0.615,  -0.51499, -0.10001]], dtype=np.float32)
    yuv = rgb @ M.T
    return yuv

def yuv_to_rgb(yuv: np.ndarray) -> np.ndarray:
    if _HAS_CV2:
        return cv2.cvtColor(yuv.astype(np.float32), cv2.COLOR_YUV2RGB)
    M = np.array([[1.0,  0.0,      1.13983],
                  [1.0, -0.39465, -0.58060],
                  [1.0,  2.03211,  0.0     ]], dtype=np.float32)
    rgb = yuv @ M.T
    return rgb

def selective_denoise(rgb: np.ndarray, T_gamma: np.ndarray, method: str = "nlmeans") -> np.ndarray:
    """
    Denoise only dark regions (where illumination is small).
    We do NLMeans on Y channel and recombine:
        R_final = R * T + R_denoised * (1 - T)
    """
    R = np.clip(rgb, 0.0, 1.0)
    T3 = T_gamma[..., None]

    if method.lower() == "none":
        return R

    # Convert to YUV and denoise only Y
    yuv = rgb_to_yuv(R)
    Y = yuv[..., 0]

    # Estimate noise sigma (rough)
    sigma_est = float(np.mean(estimate_sigma(Y, channel_axis=None)))
    # NLMeans params—mild
    patch_kw = dict(patch_size=5, patch_distance=6, fast_mode=True)
    Y_dn = denoise_nl_means(Y, h=0.8 * sigma_est + 1e-3, **patch_kw)
    yuv_dn = yuv.copy()
    yuv_dn[..., 0] = Y_dn
    R_dn = np.clip(yuv_to_rgb(yuv_dn), 0.0, 1.0)

    # Recompose
    R_final = R * T3 + R_dn * (1.0 - T3)
    return np.clip(R_final, 0.0, 1.0)

def enhance_image(rgb: np.ndarray, alpha: float = 0.15, gamma: float = 0.8,
                  denoise: str = "nlmeans", eps: float = EPS, use_cg: bool = False,
                  return_maps: bool = False):
    T_hat = initial_illumination(rgb)
    T_ref = refine_illumination(T_hat, alpha=alpha, eps=eps, use_cg=use_cg)
    T_gam = apply_gamma(T_ref, gamma=gamma)
    R = recover_reflectance(rgb, T_gam, eps=eps)
    R_final = selective_denoise(R, T_gam, method=denoise)
    if return_maps:
        return R_final, T_hat, T_ref, T_gam
    return R_final

def is_image_file(name: str) -> bool:
    ext = os.path.splitext(name)[1].lower()
    return ext in [".png", ".jpg", ".jpeg", ".bmp", ".tiff"]

def run_cli():
    ap = argparse.ArgumentParser(description="LIME low-light enhancement (minimal)")
    ap.add_argument("--input", required=True, help="Path to an image or a folder of images")
    ap.add_argument("--output", default=None, help="Output file or folder (default: alongside inputs)")
    ap.add_argument("--alpha", type=float, default=0.15, help="Regularization strength (0.1~0.3 reasonable)")
    ap.add_argument("--gamma", type=float, default=0.8, help="Gamma for illumination (0.6~0.9 reasonable)")
    ap.add_argument("--denoise", type=str, default="nlmeans", choices=["nlmeans","none"], help="Selective denoising method")
    ap.add_argument("--use_cg", action="store_true", help="Use Conjugate Gradient (fallback to direct if needed)")
    ap.add_argument("--save_maps", action="store_true", help="Save illumination maps (T_hat, T_ref, T_gamma)")
    args = ap.parse_args()

    inp = args.input
    out = args.output

    if os.path.isdir(inp):
        files = [f for f in os.listdir(inp) if is_image_file(f)]
        if not files:
            print("No images found in the folder.")
            return
        if out is None:
            out = os.path.join(inp, "lime_out")
        os.makedirs(out, exist_ok=True)

        for f in files:
            in_path = os.path.join(inp, f)
            rgb = read_image(in_path)
            if args.save_maps:
                R, T_hat, T_ref, T_gam = enhance_image(rgb, alpha=args.alpha, gamma=args.gamma,
                                                       denoise=args.denoise, use_cg=args.use_cg,
                                                       return_maps=True)
            else:
                R = enhance_image(rgb, alpha=args.alpha, gamma=args.gamma,
                                  denoise=args.denoise, use_cg=args.use_cg, return_maps=False)

            name = os.path.splitext(f)[0]
            save_image(os.path.join(out, f"{name}_enhanced.png"), R)
            if args.save_maps:
                # Save maps for visualization
                def norm01(x):
                    x = x - x.min()
                    m = x.max() + 1e-8
                    return x / m
                save_image(os.path.join(out, f"{name}_T_hat.png"), np.stack([norm01(T_hat)]*3, axis=-1))
                save_image(os.path.join(out, f"{name}_T_ref.png"), np.stack([norm01(T_ref)]*3, axis=-1))
                save_image(os.path.join(out, f"{name}_T_gamma.png"), np.stack([norm01(T_gam)]*3, axis=-1))

            print(f"Processed: {f}")
        print(f"Done. Results at: {out}")
    else:
        rgb = read_image(inp)
        if args.save_maps:
            R, T_hat, T_ref, T_gam = enhance_image(rgb, alpha=args.alpha, gamma=args.gamma,
                                                   denoise=args.denoise, use_cg=args.use_cg,
                                                   return_maps=True)
        else:
            R = enhance_image(rgb, alpha=args.alpha, gamma=args.gamma,
                              denoise=args.denoise, use_cg=args.use_cg, return_maps=False)

        if out is None:
            root = os.path.dirname(inp) or "."
            name = os.path.splitext(os.path.basename(inp))[0]
            out = os.path.join(root, f"{name}_enhanced.png")

        # If output is a directory, write inside it
        if os.path.isdir(out):
            name = os.path.splitext(os.path.basename(inp))[0]
            out_img = os.path.join(out, f"{name}_enhanced.png")
        else:
            out_img = out
        os.makedirs(os.path.dirname(out_img) or ".", exist_ok=True)
        save_image(out_img, R)

        if args.save_maps:
            def norm01(x):
                x = x - x.min()
                m = x.max() + 1e-8
                return x / m
            base = os.path.splitext(out_img)[0]
            save_image(base + "_T_hat.png", np.stack([norm01(T_hat)]*3, axis=-1))
            save_image(base + "_T_ref.png", np.stack([norm01(T_ref)]*3, axis=-1))
            save_image(base + "_T_gamma.png", np.stack([norm01(T_gam)]*3, axis=-1))

        print(f"Saved: {out_img}")

if __name__ == "__main__":
    run_cli()
