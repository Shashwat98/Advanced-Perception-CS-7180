
"""
Shashwat Singh
CS-7180 Advance Perception
18/9/2025

Evaluate LIME vs Zero-DCE++ outputs on no-reference image quality + exposure stats.
- Saves per-image CSVs for each method + sample montages.
"""

import os
import time
import glob
import csv
import numpy as np
import cv2
from skimage.metrics import peak_signal_noise_ratio as psnr, structural_similarity as ssim
from typing import List, Tuple, Optional

# ---------- Image I/O ----------
"""
Reads an image from disk with OpenCV, converts BGR to RGB
Returns uint8 array in shape HxWx3 with values 0-255
"""
def read_img(path: str) -> np.ndarray:
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise RuntimeError(f"Failed to read: {path}")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img  # uint8 [0..255], HxWx3

"""
Converts an image to float64 in the range 0,1 otherwise casts to float
"""
def to_float01(img: np.ndarray) -> np.ndarray:
    if img.dtype == np.uint8:
        return img.astype(np.float64) / 255.0
    return img.astype(np.float64)

"""
Resizes an image a so it matches b's height and width
"""
def safe_resize(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    h, w = b.shape[:2]
    return cv2.resize(a, (w, h), interpolation=cv2.INTER_CUBIC)

# ---------- Simple stats ----------

"""
Computes per-channel histogram entropy (information/content proxy).
Averages the 3 channel entropies → single score. Higher ≈ richer detail/contrast.
"""
def entropy_rgb(img_u8: np.ndarray) -> float:
    # Channel-wise hist then average entropy; quick proxy
    ent = 0.0
    for ch in range(3):
        hist = cv2.calcHist([img_u8],[ch],None,[256],[0,256]).ravel()
        p = hist / (hist.sum() + 1e-12)
        p = p[p > 0]
        ent += -(p * np.log2(p)).sum()
    return float(ent / 3.0)

"""
Measures percentage of pixels that are clipped to 0 or 255
"""
def clip_rate(img_u8: np.ndarray) -> Tuple[float, float]:
    zeros = np.mean((img_u8 == 0).any(axis=2)) * 100.0
    maxes = np.mean((img_u8 == 255).any(axis=2)) * 100.0
    return float(zeros), float(maxes)

"""
Converts to grayscale and returns the mean intensity (0–255).

Quick exposure indicator (higher = brighter).
"""
def mean_brightness(img_u8: np.ndarray) -> float:
    return float(cv2.cvtColor(img_u8, cv2.COLOR_RGB2GRAY).mean())

"""
Computes channel means (R,G,B) and returns relative std-dev / mean.

Lower value -> channels more balanced (closer to “gray world” assumption).
"""
def gray_world_error(img_u8: np.ndarray) -> float:
    means = img_u8.reshape(-1,3).mean(axis=0)  # on 0..255
    return float(np.std(means) / (means.mean() + 1e-6))

# ---------- No-reference metrics ----------

"""
Tries to compute NIQE (via scikit-image) and BRISQUE (via imquality.brisque).
Returns (niqe, brisque, piqe); PIQE is left as None for compatibility
"""
def try_no_ref_metrics(img_u8: np.ndarray) -> Tuple[Optional[float], Optional[float], Optional[float]]:

    N = BQ = PQ = None

    # NIQE (scikit-image >= 0.21). Accepts float [0,1], RGB or gray.
    try:
        from skimage.metrics import niqe as sk_niqe
        N = float(sk_niqe(to_float01(img_u8)))
    except Exception:
        N = None

    # BRISQUE (optional)
    try:
        from imquality import brisque
        # brisque.score accepts uint8 color; grayscale may be slightly faster.
        BQ = float(brisque.score(img_u8))
    except Exception:
        BQ = None

    return N, BQ, PQ  # PIQE left as None for compatibility

# ---------- Montage helper ----------

def save_montage(paths_in: List[Optional[str]], save_path: str, width: int = 3) -> None:
    imgs = []
    for p in paths_in:
        if p and os.path.exists(p):
            try:
                im = read_img(p)
                imgs.append(im)
            except Exception:
                pass
    if not imgs:
        return
    # Normalize heights for a tidy grid
    hmin = min(im.shape[0] for im in imgs)
    imgs = [cv2.resize(im, (int(im.shape[1]*hmin/im.shape[0]), hmin)) for im in imgs]
    rows = []
    for i in range(0, len(imgs), width):
        row = np.concatenate(imgs[i:i+width], axis=1)
        rows.append(row)
    grid = np.concatenate(rows, axis=0)
    cv2.imwrite(save_path, cv2.cvtColor(grid, cv2.COLOR_RGB2BGR))

# ---------- Pairing ----------

def list_pairs(folder_out: str, folder_gt: Optional[str]=None) -> List[Tuple[str, Optional[str]]]:
    outs = sorted(glob.glob(os.path.join(folder_out, '*')))
    pairs = []
    for o in outs:
        if not os.path.isfile(o):
            continue
        name = os.path.basename(o)
        g = os.path.join(folder_gt, name) if folder_gt else None
        pairs.append((o, g if g and os.path.exists(g) else None))
    return pairs

# ---------- Folder timing (I/O only placeholder) ----------

def time_folder(folder: str) -> Tuple[float, int]:
    files = sorted(glob.glob(os.path.join(folder, '*')))
    t0 = time.time()
    cnt = 0
    for f in files:
        if os.path.isfile(f):
            _ = read_img(f)
            cnt += 1
    dt = time.time() - t0
    return dt, cnt

# ---------- Core evaluation ----------

def evaluate(method_name: str,
             out_dir: str,
             gt_dir: Optional[str],
             csv_path: str,
             sample_figure_dir: str,
             ref_inputs_dir: Optional[str]=None) -> None:

    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    os.makedirs(sample_figure_dir, exist_ok=True)

    pairs = list_pairs(out_dir, gt_dir)
    if not pairs:
        print(f"[{method_name}] No files found in: {out_dir}")
        return

    with open(csv_path, 'w', newline='') as f:
        w = csv.writer(f)
        header = ["image","method","psnr","ssim","niqe","brisque","piqe",
                  "mean_brightness","entropy","clip_0_pct","clip_255_pct","gray_world_err"]
        w.writerow(header)

        sample_imgs: List[Optional[str]] = []
        for (out_path, maybe_gt) in pairs:
            out_img = read_img(out_path)
            # Paired metrics if GT exists
            P = S = None
            if maybe_gt:
                gt_img = read_img(maybe_gt)
                out_r = safe_resize(out_img, gt_img)
                # skimage expects float, specify data_range
                P = psnr(gt_img, out_r, data_range=255)
                # Newer skimage uses channel_axis
                S = ssim(gt_img, out_r, channel_axis=2, data_range=255)

            # No-reference metrics
            N, BQ, PQ = try_no_ref_metrics(out_img)

            # Exposure / color stats
            mb = mean_brightness(out_img)
            ent = entropy_rgb(out_img)
            c0, c255 = clip_rate(out_img)
            gwe = gray_world_error(out_img)

            w.writerow([
                os.path.basename(out_path), method_name,
                P, S, N, BQ, PQ,
                mb, ent, c0, c255, gwe
            ])

            # Collect examples for montage: [input | output | (GT)]
            if len(sample_imgs) < 12:
                row: List[Optional[str]] = []
                if ref_inputs_dir:
                    inp = os.path.join(ref_inputs_dir, os.path.basename(out_path))
                    row.append(inp if os.path.exists(inp) else None)
                row.append(out_path)
                if maybe_gt:
                    row.append(maybe_gt)
                sample_imgs.extend(row)

        # Save montage
        fig_path = os.path.join(sample_figure_dir, f"{method_name}_samples.jpg")
        save_montage(sample_imgs, fig_path, width=3)
        print(f"[{method_name}] Wrote: {csv_path}")
        print(f"[{method_name}] Montage: {fig_path}")

# ---------- Main ----------

if __name__ == "__main__":
    ROOT = "project"
    LOW  = os.path.join(ROOT, "data", "low")
    GT   = os.path.join(ROOT, "data", "gt")     # optional
    LIME = os.path.join(ROOT, "outputs", "lime")
    DCE  = os.path.join(ROOT, "outputs", "zerodcepp")
    EVAL = os.path.join(ROOT, "eval")

    # Evaluate per-method
    evaluate("LIME",
             LIME,
             GT if os.path.exists(GT) else None,
             os.path.join(EVAL, "tables", "lime_metrics.csv"),
             os.path.join(EVAL, "figures"),
             ref_inputs_dir=LOW)

    evaluate("ZeroDCEpp",
             DCE,
             GT if os.path.exists(GT) else None,
             os.path.join(EVAL, "tables", "zerodcepp_metrics.csv"),
             os.path.join(EVAL, "figures"),
             ref_inputs_dir=LOW)

    # Optional folder I/O timing (placeholder, not inference latency)
    for name, path in [("LIME", LIME), ("ZeroDCEpp", DCE)]:
        if os.path.exists(path):
            dt, n = time_folder(path)
            print(f"[{name}] scanned {n} files in {dt:.3f}s (I/O only)")
